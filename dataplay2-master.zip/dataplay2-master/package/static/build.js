({
    baseUrl: "./lib",
    paths: {
		comp: './components',
		viz: './visualization',
		event: './event',
		data: './data'
    },
    name: "app",
    out: "main-built.js"
})