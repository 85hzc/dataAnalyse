// Handle data transformation and manipultation
define([], function() {
    var service = {};

    return service;
});
