define(["viz/xc1ymn"], function(Base) {
    var me = new Base();
    me.meta.name = "line";
    me.meta.chartName = "line";
    return me;
});