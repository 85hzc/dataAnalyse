define(["viz/xm1ym1cc1"], function(Base) {
    var me = new Base();
    me.meta.name = "scatter";
    me.meta.chartName = "scatter";
    return me;
});
