define(["viz/xc1ymn"], function(Base) {
    var me = new Base();
    me.meta.name = "bar";
    me.meta.chartName = "bar";
    return me;
});
