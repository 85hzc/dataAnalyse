define([], function() {
    var Main = React.createClass({
    render: function() {
        return ( 
            <div>
                <img src="resources/main.png"></img>
            </div>
        );
        }
    });

    return Main;
});