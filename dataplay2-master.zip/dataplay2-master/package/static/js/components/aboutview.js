define([], function() {
    var AboutPage = React.createClass({
        render: function() {
            return ( 
                <div>
                    This is the about page!
                </div>
            );
        }
    });

    return AboutPage;
});